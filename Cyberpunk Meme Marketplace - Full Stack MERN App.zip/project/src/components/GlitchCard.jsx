import React from 'react';

const GlitchCard = ({ children, className = '' }) => {
  return (
    <div className={`
      relative bg-black/80 border border-cyan-500/30 rounded-lg p-4
      transition-all duration-300 hover:border-pink-500/50
      hover:shadow-lg hover:shadow-cyan-500/20
      before:absolute before:inset-0 before:bg-gradient-to-r 
      before:from-transparent before:via-cyan-500/5 before:to-transparent
      before:translate-x-[-100%] hover:before:translate-x-[100%]
      before:transition-transform before:duration-700
      glitch-hover
      ${className}
    `}>
      {children}
    </div>
  );
};

export default GlitchCard;