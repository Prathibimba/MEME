import React, { useState, useEffect } from 'react';
import { ChevronUp, ChevronDown, Zap, Coins, RefreshCw } from 'lucide-react';
import GlitchCard from './GlitchCard';
import TerminalText from './TerminalText';
import { api } from '../services/api';

const MemeCard = ({ meme, socket, onMemeUpdate }) => {
  const [votes, setVotes] = useState({ upvotes: meme.upvotes, downvotes: meme.downvotes });
  const [bidAmount, setBidAmount] = useState('');
  const [bids, setBids] = useState([]);
  const [isVoting, setIsVoting] = useState(false);
  const [caption, setCaption] = useState(meme.caption);
  const [isGeneratingCaption, setIsGeneratingCaption] = useState(false);

  useEffect(() => {
    if (socket) {
      socket.on('vote_update', (data) => {
        if (data.memeId === meme.id) {
          setVotes({ upvotes: data.upvotes, downvotes: data.downvotes });
          if (onMemeUpdate) {
            onMemeUpdate({ ...meme, upvotes: data.upvotes, downvotes: data.downvotes });
          }
        }
      });

      socket.on('bid_update', (data) => {
        if (data.memeId === meme.id) {
          setBids(prev => [data.bid, ...prev].slice(0, 3));
        }
      });
    }

    // Load initial bids
    api.getBids(meme.id).then(setBids).catch(console.error);

    return () => {
      if (socket) {
        socket.off('vote_update');
        socket.off('bid_update');
      }
    };
  }, [meme.id, socket, onMemeUpdate]);

  const handleVote = async (type) => {
    if (isVoting) return;
    setIsVoting(true);
    
    try {
      const updatedMeme = await api.voteMeme(meme.id, type);
      setVotes({ upvotes: updatedMeme.upvotes, downvotes: updatedMeme.downvotes });
      if (onMemeUpdate) {
        onMemeUpdate(updatedMeme);
      }
    } catch (error) {
      console.error('Vote failed:', error);
    } finally {
      setTimeout(() => setIsVoting(false), 1000);
    }
  };

  const handleBid = async (e) => {
    e.preventDefault();
    if (!bidAmount || parseFloat(bidAmount) <= 0) return;
    
    try {
      const newBid = await api.placeBid(meme.id, parseFloat(bidAmount));
      setBids(prev => [newBid, ...prev].slice(0, 3));
      setBidAmount('');
    } catch (error) {
      console.error('Bid failed:', error);
    }
  };

  const handleGenerateCaption = async () => {
    if (isGeneratingCaption) return;
    setIsGeneratingCaption(true);
    
    try {
      const result = await api.generateCaption(meme.id);
      setCaption(result.caption);
    } catch (error) {
      console.error('Caption generation failed:', error);
    } finally {
      setIsGeneratingCaption(false);
    }
  };

  const topBid = bids.length > 0 ? bids[0] : null;

  return (
    <GlitchCard className="w-full max-w-md mx-auto">
      <div className="space-y-4">
        {/* Image */}
        <div className="relative overflow-hidden rounded-lg">
          <img
            src={meme.image_url}
            alt={meme.title}
            className="w-full h-48 object-cover transition-transform duration-300 hover:scale-105"
            onError={(e) => {
              e.target.src = `https://picsum.photos/400/300?random=${meme.id}`;
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        </div>

        {/* Title */}
        <h3 className="text-xl font-bold text-cyan-400 glitch-text">
          {meme.title}
        </h3>

        {/* Caption with Terminal Effect and Regenerate Button */}
        <div className="space-y-2">
          <div className="bg-black/50 border border-green-500/20 rounded p-2 min-h-[3rem] flex items-center">
            <TerminalText 
              text={caption} 
              speed={30}
              className="text-green-400 text-sm flex-1"
            />
          </div>
          <button
            onClick={handleGenerateCaption}
            disabled={isGeneratingCaption}
            className="w-full px-3 py-1 bg-green-500/20 border border-green-500/30 rounded text-green-400 text-xs
                     hover:bg-green-500/30 transition-colors disabled:opacity-50 flex items-center justify-center space-x-1"
          >
            <RefreshCw className={`w-3 h-3 ${isGeneratingCaption ? 'animate-spin' : ''}`} />
            <span>{isGeneratingCaption ? 'GENERATING...' : 'NEW CAPTION'}</span>
          </button>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-2">
          {meme.tags && meme.tags.map((tag, index) => (
            <span
              key={index}
              className="px-2 py-1 bg-pink-500/20 border border-pink-500/30 rounded text-pink-400 text-xs"
            >
              #{tag}
            </span>
          ))}
        </div>

        {/* Voting */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleVote('upvote')}
              disabled={isVoting}
              className="flex items-center space-x-1 px-3 py-2 bg-green-500/20 border border-green-500/30 rounded
                       hover:bg-green-500/30 transition-colors disabled:opacity-50"
            >
              <ChevronUp className="w-4 h-4 text-green-400" />
              <span className="text-green-400 font-bold">{votes.upvotes}</span>
            </button>
            
            <button
              onClick={() => handleVote('downvote')}
              disabled={isVoting}
              className="flex items-center space-x-1 px-3 py-2 bg-red-500/20 border border-red-500/30 rounded
                       hover:bg-red-500/30 transition-colors disabled:opacity-50"
            >
              <ChevronDown className="w-4 h-4 text-red-400" />
              <span className="text-red-400 font-bold">{votes.downvotes}</span>
            </button>
          </div>

          {topBid && (
            <div className="flex items-center space-x-1 text-yellow-400">
              <Coins className="w-4 h-4" />
              <span className="font-bold">{topBid.credits}</span>
            </div>
          )}
        </div>

        {/* Bidding */}
        <form onSubmit={handleBid} className="space-y-2">
          <div className="flex space-x-2">
            <input
              type="number"
              value={bidAmount}
              onChange={(e) => setBidAmount(e.target.value)}
              placeholder="Enter bid..."
              min="1"
              className="flex-1 px-3 py-2 bg-black/50 border border-cyan-500/30 rounded text-cyan-400
                       placeholder-cyan-400/50 focus:border-cyan-500 focus:outline-none"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-pink-500 rounded font-bold
                       hover:from-cyan-600 hover:to-pink-600 transition-all duration-300
                       flex items-center space-x-1"
            >
              <Zap className="w-4 h-4" />
              <span>BID</span>
            </button>
          </div>
          
          {bids.length > 0 && (
            <div className="text-xs text-cyan-400/70">
              Recent bids: {bids.slice(0, 3).map(b => b.credits).join(', ')}
            </div>
          )}
        </form>
      </div>
    </GlitchCard>
  );
};

export default MemeCard;