import React, { useState, useEffect } from 'react';
import { Trophy, Crown, Medal } from 'lucide-react';
import GlitchCard from './GlitchCard';
import { api } from '../services/api';

const Leaderboard = () => {
  const [leaderboard, setLeaderboard] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLeaderboard = async () => {
      try {
        const data = await api.getLeaderboard(10);
        setLeaderboard(data);
      } catch (error) {
        console.error('Failed to fetch leaderboard:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchLeaderboard();
    const interval = setInterval(fetchLeaderboard, 10000); // Update every 10s

    return () => clearInterval(interval);
  }, []);

  const getRankIcon = (rank) => {
    switch (rank) {
      case 0: return <Crown className="w-6 h-6 text-yellow-400" />;
      case 1: return <Medal className="w-6 h-6 text-gray-300" />;
      case 2: return <Medal className="w-6 h-6 text-orange-400" />;
      default: return <Trophy className="w-5 h-5 text-cyan-400" />;
    }
  };

  if (loading) {
    return (
      <GlitchCard className="w-full max-w-md mx-auto">
        <div className="text-center text-cyan-400">Loading leaderboard...</div>
      </GlitchCard>
    );
  }

  return (
    <GlitchCard className="w-full max-w-md mx-auto">
      <div className="space-y-4">
        <div className="flex items-center space-x-2 mb-4">
          <Trophy className="w-6 h-6 text-yellow-400" />
          <h2 className="text-2xl font-bold text-cyan-400 glitch-text">
            TOP MEMES
          </h2>
        </div>

        <div className="space-y-3">
          {leaderboard.map((meme, index) => (
            <div
              key={meme.id}
              className={`flex items-center space-x-3 p-3 rounded-lg border ${
                index === 0 
                  ? 'bg-yellow-500/10 border-yellow-500/30' 
                  : 'bg-black/30 border-cyan-500/20'
              }`}
            >
              <div className="flex-shrink-0">
                {getRankIcon(index)}
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-cyan-400 truncate">
                  {meme.title}
                </div>
                <div className="text-xs text-cyan-400/70">
                  {meme.upvotes} upvotes
                </div>
              </div>
              
              <div className="flex-shrink-0 text-right">
                <div className="text-lg font-bold text-green-400">
                  #{index + 1}
                </div>
              </div>
            </div>
          ))}
        </div>

        {leaderboard.length === 0 && (
          <div className="text-center text-cyan-400/70 py-8">
            No memes yet. Be the first to create one!
          </div>
        )}
      </div>
    </GlitchCard>
  );
};

export default Leaderboard;