import React, { useState } from 'react';
import { Plus, Zap } from 'lucide-react';
import GlitchCard from './GlitchCard';
import { api } from '../services/api';

const MemeForm = ({ onMemeCreated }) => {
  const [formData, setFormData] = useState({
    title: '',
    image_url: '',
    tags: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim()) return;

    setIsSubmitting(true);
    try {
      const newMeme = await api.createMeme({
        ...formData,
        image_url: formData.image_url || `https://picsum.photos/400/300?random=${Date.now()}`,
        tags: formData.tags.split(',').map(tag => tag.trim()).filter(Boolean)
      });
      
      onMemeCreated(newMeme);
      setFormData({ title: '', image_url: '', tags: '' });
    } catch (error) {
      console.error('Failed to create meme:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <GlitchCard className="w-full max-w-2xl mx-auto">
      <div className="space-y-4">
        <div className="flex items-center space-x-2 mb-4">
          <Zap className="w-6 h-6 text-cyan-400" />
          <h2 className="text-2xl font-bold text-cyan-400 glitch-text">
            CREATE MEME
          </h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-cyan-400 mb-2">
              Title
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3 py-2 bg-black/50 border border-cyan-500/30 rounded text-cyan-400
                       placeholder-cyan-400/50 focus:border-cyan-500 focus:outline-none"
              placeholder="Enter meme title..."
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-cyan-400 mb-2">
              Image URL (optional)
            </label>
            <input
              type="url"
              value={formData.image_url}
              onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
              className="w-full px-3 py-2 bg-black/50 border border-cyan-500/30 rounded text-cyan-400
                       placeholder-cyan-400/50 focus:border-cyan-500 focus:outline-none"
              placeholder="https://example.com/image.jpg (or leave blank for random)"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-cyan-400 mb-2">
              Tags
            </label>
            <input
              type="text"
              value={formData.tags}
              onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
              className="w-full px-3 py-2 bg-black/50 border border-cyan-500/30 rounded text-cyan-400
                       placeholder-cyan-400/50 focus:border-cyan-500 focus:outline-none"
              placeholder="crypto, moon, cyberpunk, memes (comma-separated)"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full px-6 py-3 bg-gradient-to-r from-cyan-500 to-pink-500 rounded font-bold
                     hover:from-cyan-600 hover:to-pink-600 transition-all duration-300
                     flex items-center justify-center space-x-2 disabled:opacity-50"
          >
            <Plus className="w-5 h-5" />
            <span>{isSubmitting ? 'CREATING...' : 'CREATE MEME'}</span>
          </button>
        </form>
      </div>
    </GlitchCard>
  );
};

export default MemeForm;