import React from 'react';

const CyberpunkBackground = () => {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      {/* Animated Grid */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-[linear-gradient(90deg,_cyan_1px,_transparent_1px),_linear-gradient(0deg,_cyan_1px,_transparent_1px)]
                        bg-[size:50px_50px] animate-pulse"></div>
      </div>
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-purple-900/20 to-black"></div>
      
      {/* Glowing Orbs */}
      <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-pink-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      
      {/* Scanning Lines */}
      <div className="absolute inset-0 bg-[linear-gradient(180deg,_transparent_98%,_cyan_99%,_transparent_100%)]
                      bg-[size:100%_100px] animate-scan"></div>
    </div>
  );
};

export default CyberpunkBackground;