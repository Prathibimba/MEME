import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

export const useSocket = () => {
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    // Create a mock socket object that uses Supabase real-time subscriptions
    const mockSocket = {
      listeners: {},
      
      on(event, callback) {
        if (!this.listeners[event]) {
          this.listeners[event] = [];
        }
        this.listeners[event].push(callback);
      },
      
      off(event, callback) {
        if (this.listeners[event]) {
          this.listeners[event] = this.listeners[event].filter(cb => cb !== callback);
        }
      },
      
      emit(event, data) {
        if (this.listeners[event]) {
          this.listeners[event].forEach(callback => callback(data));
        }
      }
    };

    // Set up Supabase real-time subscriptions
    const memeSubscription = supabase
      .channel('memes')
      .on('postgres_changes', 
        { event: 'INSERT', schema: 'public', table: 'memes' },
        (payload) => {
          mockSocket.emit('meme_created', payload.new);
        }
      )
      .on('postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'memes' },
        (payload) => {
          mockSocket.emit('vote_update', {
            memeId: payload.new.id,
            upvotes: payload.new.upvotes,
            downvotes: payload.new.downvotes
          });
        }
      )
      .subscribe();

    const bidSubscription = supabase
      .channel('bids')
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'bids' },
        (payload) => {
          mockSocket.emit('bid_update', {
            memeId: payload.new.meme_id,
            bid: payload.new
          });
        }
      )
      .subscribe();

    setSocket(mockSocket);

    return () => {
      supabase.removeChannel(memeSubscription);
      supabase.removeChannel(bidSubscription);
    };
  }, []);

  return socket;
};