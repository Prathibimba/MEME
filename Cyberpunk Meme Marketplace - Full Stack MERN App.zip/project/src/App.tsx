import React, { useState, useEffect } from 'react';
import { Zap } from 'lucide-react';
import CyberpunkBackground from './components/CyberpunkBackground';
import MemeForm from './components/MemeForm';
import MemeCard from './components/MemeCard';
import Leaderboard from './components/Leaderboard';
import TerminalText from './components/TerminalText';
import { useSocket } from './hooks/useSocket';
import { api } from './services/api';

function App() {
  const [memes, setMemes] = useState([]);
  const [loading, setLoading] = useState(true);
  const socket = useSocket();

  useEffect(() => {
    // Load initial memes
    const loadMemes = async () => {
      try {
        const data = await api.getMemes();
        setMemes(data);
      } catch (error) {
        console.error('Failed to load memes:', error);
      } finally {
        setLoading(false);
      }
    };

    loadMemes();
  }, []);

  useEffect(() => {
    if (socket) {
      socket.on('meme_created', (newMeme) => {
        setMemes(prev => [newMeme, ...prev]);
      });

      return () => {
        socket.off('meme_created');
      };
    }
  }, [socket]);

  const handleMemeCreated = (newMeme) => {
    setMemes(prev => [newMeme, ...prev]);
  };

  const handleMemeUpdate = (updatedMeme) => {
    setMemes(prev => prev.map(meme => 
      meme.id === updatedMeme.id ? updatedMeme : meme
    ));
  };

  return (
    <div className="min-h-screen bg-black text-white relative">
      <CyberpunkBackground />
      
      {/* Header */}
      <header className="relative z-10 px-4 py-8">
        <div className="max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-4 mb-4">
            <Zap className="w-12 h-12 text-cyan-400 animate-pulse" />
            <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-cyan-400 via-pink-500 to-cyan-400 bg-clip-text text-transparent glitch-text">
              MEME NEXUS
            </h1>
            <Zap className="w-12 h-12 text-pink-500 animate-pulse" />
          </div>
          
          <div className="text-cyan-400 text-lg font-mono">
            <TerminalText 
              text=">>> Welcome to the Cyberpunk Meme Marketplace <<<"
              speed={50}
            />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 px-4 pb-8">
        <div className="max-w-6xl mx-auto">
          {/* Create Meme Section */}
          <section className="mb-12">
            <MemeForm onMemeCreated={handleMemeCreated} />
          </section>

          {/* Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Memes Gallery */}
            <div className="lg:col-span-3">
              <h2 className="text-2xl font-bold text-cyan-400 mb-6 glitch-text">
                MEME GALLERY
              </h2>
              
              {loading ? (
                <div className="text-center text-cyan-400 py-12">
                  <div className="animate-spin w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full mx-auto mb-4"></div>
                  Loading memes...
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {memes.map((meme) => (
                    <MemeCard 
                      key={meme.id} 
                      meme={meme} 
                      socket={socket} 
                      onMemeUpdate={handleMemeUpdate}
                    />
                  ))}
                </div>
              )}
              
              {!loading && memes.length === 0 && (
                <div className="text-center text-cyan-400/70 py-12">
                  <div className="text-6xl mb-4">🚀</div>
                  <div className="text-xl font-bold mb-2">No memes yet!</div>
                  <div>Be the first to create an epic meme</div>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1 space-y-8">
              <Leaderboard />
              
              {/* Stats */}
              <div className="bg-black/80 border border-cyan-500/30 rounded-lg p-4">
                <h3 className="text-lg font-bold text-cyan-400 mb-4">NEXUS STATS</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-cyan-400/70">Total Memes:</span>
                    <span className="text-green-400 font-bold">{memes.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-cyan-400/70">Active Users:</span>
                    <span className="text-green-400 font-bold">420</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-cyan-400/70">Total Votes:</span>
                    <span className="text-green-400 font-bold">
                      {memes.reduce((sum, meme) => sum + meme.upvotes + meme.downvotes, 0)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 px-4 py-8 mt-16 border-t border-cyan-500/20">
        <div className="max-w-6xl mx-auto text-center text-cyan-400/70">
          <p className="font-mono">
            Built with ⚡ by AI-powered cyberpunks | MEME NEXUS v2.0.77
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;