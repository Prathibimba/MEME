import { db } from '../lib/supabase';

// AI Caption Generation
async function generateCaption(title, tags) {
  const fallbackCaptions = [
    "YOLO to the moon! 🚀",
    "Neon Crypto Chaos incoming! 💎",
    "Glitch in the Matrix detected! 🔥",
    "Cyberpunk vibes activated! ⚡",
    "Hack the planet! 🌍",
    "Neural network overload! 🧠",
    "Digital rebellion starts now! 💀",
    "Code red in cyberspace! 🔴",
    "Matrix has you... 👾",
    "Cyber samurai mode ON! ⚔️"
  ];

  // For now, use fallback captions (can be enhanced with actual AI later)
  return fallbackCaptions[Math.floor(Math.random() * fallbackCaptions.length)];
}

export const api = {
  // Memes
  getMemes: async () => {
    try {
      return await db.getMemes();
    } catch (error) {
      console.error('Failed to fetch memes:', error);
      return [];
    }
  },

  createMeme: async (memeData) => {
    try {
      // Generate AI caption
      const caption = await generateCaption(memeData.title, memeData.tags);
      
      const newMeme = {
        ...memeData,
        caption,
        vibe: "Neon Cyber Chaos",
        upvotes: 0,
        downvotes: 0,
        owner_id: 'cyberpunk420'
      };

      return await db.createMeme(newMeme);
    } catch (error) {
      console.error('Failed to create meme:', error);
      throw error;
    }
  },

  voteMeme: async (memeId, type) => {
    try {
      // Get current meme data
      const memes = await db.getMemes();
      const meme = memes.find(m => m.id === memeId);
      
      if (!meme) throw new Error('Meme not found');

      let newUpvotes = meme.upvotes;
      let newDownvotes = meme.downvotes;

      if (type === 'upvote') {
        newUpvotes += 1;
      } else if (type === 'downvote') {
        newDownvotes += 1;
      }

      return await db.updateMemeVotes(memeId, newUpvotes, newDownvotes);
    } catch (error) {
      console.error('Failed to vote on meme:', error);
      throw error;
    }
  },

  placeBid: async (memeId, credits) => {
    try {
      const bidData = {
        meme_id: memeId,
        user_id: 'cyberpunk420',
        credits: parseInt(credits)
      };

      return await db.createBid(bidData);
    } catch (error) {
      console.error('Failed to place bid:', error);
      throw error;
    }
  },

  getBids: async (memeId) => {
    try {
      return await db.getBids(memeId);
    } catch (error) {
      console.error('Failed to fetch bids:', error);
      return [];
    }
  },

  getLeaderboard: async (top = 10) => {
    try {
      return await db.getLeaderboard(top);
    } catch (error) {
      console.error('Failed to fetch leaderboard:', error);
      return [];
    }
  },

  generateCaption: async (memeId) => {
    try {
      // Get meme data
      const memes = await db.getMemes();
      const meme = memes.find(m => m.id === memeId);
      
      if (!meme) throw new Error('Meme not found');

      const newCaption = await generateCaption(meme.title, meme.tags);
      await db.updateMemeCaption(memeId, newCaption);
      
      return { caption: newCaption };
    } catch (error) {
      console.error('Failed to generate caption:', error);
      throw error;
    }
  },
};