# 🚀 Meme Nexus - Cyberpunk Meme Marketplace

A full-stack MERN application featuring a cyberpunk-themed meme marketplace with real-time bidding, voting, and AI-powered caption generation.

## ✨ Features

### 🎨 Frontend (React + Tailwind CSS)
- **Cyberpunk Theme**: Neon colors, glitch effects, and terminal aesthetics
- **Real-time Updates**: Live bidding and voting with WebSocket integration
- **Meme Creation**: Form with title, image URL, and tags
- **Interactive Voting**: Upvote/downvote with live counters
- **Leaderboard**: Top 10 memes by upvotes
- **Terminal Effects**: Fake typing animation for captions
- **Glitch Animations**: Hover effects and RGB color shifting

### 🔧 Backend (Node.js + Express + Socket.IO)
- **RESTful API**: Full CRUD operations for memes
- **Real-time Communication**: Socket.IO for live updates
- **In-memory Storage**: Quick prototyping with fallback data
- **Mock Authentication**: Hardcoded cyberpunk users
- **Bidding System**: Fake credit-based bidding
- **Leaderboard Cache**: Optimized top memes retrieval

### 🧠 AI Integration (Google Gemini API)
- **Caption Generation**: AI-powered meme captions
- **Vibe Descriptions**: Cyberpunk-style descriptions
- **Fallback Responses**: Hardcoded responses when AI fails
- **Response Caching**: In-memory cache for repeated requests

### 🛢️ Database Ready (Supabase)
- **PostgreSQL Schema**: Memes and bids tables
- **Row Level Security**: User-based access control
- **Real-time Subscriptions**: Database change notifications
- **Environment Variables**: Secure configuration

## 🚀 Quick Start

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Environment Setup**
   ```bash
   cp .env.example .env
   # Add your Supabase and Gemini API keys
   ```

3. **Run Development**
   ```bash
   npm run dev
   ```

4. **Access the App**
   - Frontend: http://localhost:5173
   - Backend API: http://localhost:3001

## 🎮 API Endpoints

- `GET /api/memes` - Get all memes
- `POST /api/memes` - Create new meme
- `POST /api/memes/:id/vote` - Vote on meme
- `POST /api/memes/:id/bid` - Place bid
- `GET /api/memes/:id/bids` - Get meme bids
- `GET /api/leaderboard` - Get top memes
- `POST /api/memes/:id/caption` - Generate AI caption

## 🎨 Cyberpunk Design System

- **Primary Colors**: Cyan (#00FFFF), Pink (#FF0080)
- **Accent Colors**: Green (#00FF00), Yellow (#FFFF00)
- **Background**: Black with gradient overlays
- **Typography**: Monospace fonts (Courier New)
- **Effects**: Glitch animations, neon glows, scanning lines

## 🔧 Tech Stack

- **Frontend**: React 18, Tailwind CSS, Lucide React
- **Backend**: Node.js, Express, Socket.IO
- **Database**: Supabase (PostgreSQL)
- **AI**: Google Gemini API
- **Real-time**: WebSocket connections
- **Build Tool**: Vite
- **Deployment**: Ready for Vercel/Netlify

## 🤖 AI-Assisted Development

This project was built with significant AI assistance:
- **Gemini API Integration**: AI-powered caption generation
- **WebSocket Logic**: Real-time communication patterns
- **Glitch UI Effects**: CSS animations and transitions
- **Component Architecture**: Modular React components
- **API Design**: RESTful endpoint structure

## 🌐 Deployment

### Frontend (Vercel/Netlify)
```bash
npm run build
# Deploy dist/ folder
```

### Backend (Render/Railway)
```bash
# Set environment variables
# Deploy server/ folder
```

### Database (Supabase)
1. Create Supabase project
2. Run SQL migrations
3. Configure environment variables

## 🎯 Future Enhancements

- [ ] User authentication with Supabase Auth
- [ ] Image upload with Supabase Storage
- [ ] Meme collections and favorites
- [ ] Real-time chat during bidding
- [ ] NFT-style meme trading
- [ ] Advanced AI meme generation
- [ ] Mobile app with React Native

## 📝 License

MIT License - Feel free to hack the matrix! 🕶️

---

**Built by cyberpunks, for cyberpunks** ⚡️🚀