/*
  # Create meme marketplace tables

  1. New Tables
    - `memes`
      - `id` (uuid, primary key)
      - `title` (text)
      - `image_url` (text)
      - `tags` (text array)
      - `upvotes` (integer, default 0)
      - `downvotes` (integer, default 0)
      - `owner_id` (text)
      - `caption` (text)
      - `vibe` (text)
      - `created_at` (timestamp)
    - `bids`
      - `id` (uuid, primary key)
      - `meme_id` (uuid, foreign key)
      - `user_id` (text)
      - `credits` (integer)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for public read access
    - Add policies for authenticated users to create content
*/

-- Create memes table
CREATE TABLE IF NOT EXISTS memes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  image_url text NOT NULL,
  tags text[] DEFAULT '{}',
  upvotes integer DEFAULT 0,
  downvotes integer DEFAULT 0,
  owner_id text NOT NULL DEFAULT 'cyberpunk420',
  caption text DEFAULT 'Loading epic caption...',
  vibe text DEFAULT 'Neon Cyber Chaos',
  created_at timestamptz DEFAULT now()
);

-- Create bids table
CREATE TABLE IF NOT EXISTS bids (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meme_id uuid REFERENCES memes(id) ON DELETE CASCADE,
  user_id text NOT NULL DEFAULT 'cyberpunk420',
  credits integer NOT NULL CHECK (credits > 0),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE memes ENABLE ROW LEVEL SECURITY;
ALTER TABLE bids ENABLE ROW LEVEL SECURITY;

-- Create policies for memes (public read, anyone can create)
CREATE POLICY "Anyone can read memes"
  ON memes
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can create memes"
  ON memes
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can update meme votes"
  ON memes
  FOR UPDATE
  TO public
  USING (true);

-- Create policies for bids (public read, anyone can create)
CREATE POLICY "Anyone can read bids"
  ON bids
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can create bids"
  ON bids
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_memes_upvotes ON memes(upvotes DESC);
CREATE INDEX IF NOT EXISTS idx_memes_created_at ON memes(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_bids_meme_id ON bids(meme_id);
CREATE INDEX IF NOT EXISTS idx_bids_credits ON bids(credits DESC);